package ru.wildanalytics.pub.analytics

import android.content.Context
import ru.wildanalytics.pub.analytics.WildAnalyticsServiceLocator.Builder
import ru.wildanalytics.pub.analytics.automatic.AutomaticEventsApiKeyRegistry
import ru.wildanalytics.pub.analytics.automatic.AutomaticEventsApiKeyRegistryImpl
import ru.wildanalytics.pub.analytics.automatic.AutomaticEventsTracker
import ru.wildanalytics.pub.analytics.automatic.AutomaticEventsTrackerImpl
import ru.wildanalytics.pub.analytics.batch.BatchRepository
import ru.wildanalytics.pub.analytics.batch.BatchRepositoryImpl
import ru.wildanalytics.pub.analytics.config.ConfigRepository
import ru.wildanalytics.pub.analytics.config.ConfigRepositoryImpl
import ru.wildanalytics.pub.analytics.db.RoomTransactionRunner
import ru.wildanalytics.pub.analytics.db.TransactionRunner
import ru.wildanalytics.pub.analytics.db.WildAnalyticsDatabase
import ru.wildanalytics.pub.analytics.db.WildAnalyticsDatabaseFactory
import ru.wildanalytics.pub.analytics.device.AdIdProvider
import ru.wildanalytics.pub.analytics.device.DeviceHardwareInfoProvider
import ru.wildanalytics.pub.analytics.device.DeviceHardwareInfoProviderImpl
import ru.wildanalytics.pub.analytics.device.IpcServiceConfig
import ru.wildanalytics.pub.analytics.device.MetadataCollector
import ru.wildanalytics.pub.analytics.device.SystemLocaleProvider
import ru.wildanalytics.pub.analytics.device.SystemLocaleProviderImpl
import ru.wildanalytics.pub.analytics.device.WildDeviceInfoProvider
import ru.wildanalytics.pub.analytics.device.WildDeviceInfoProviderImpl
import ru.wildanalytics.pub.analytics.device.WildMarketingModelProvider
import ru.wildanalytics.pub.analytics.device.WildMarketingModelProviderImpl
import ru.wildanalytics.pub.analytics.event.EventsRepository
import ru.wildanalytics.pub.analytics.event.EventsRepositoryImpl
import ru.wildanalytics.pub.analytics.network.NetworkAvailabilitySource
import ru.wildanalytics.pub.analytics.send.SendAllAnalyticEventsOperation
import ru.wildanalytics.pub.analytics.send.SendOperationScheduler
import ru.wildanalytics.pub.analytics.send.SendStrategyProvider
import ru.wildanalytics.pub.analytics.send.WildAnalyticsSenderService
import ru.wildanalytics.pub.analytics.session.SessionProvider
import ru.wildanalytics.pub.analytics.session.SessionProviderImpl
import ru.wildanalytics.pub.analytics.transport.CustomHeadersRepository
import ru.wildanalytics.pub.analytics.transport.CustomHeadersRepositoryImpl
import ru.wildanalytics.pub.analytics.util.DynamicSystemClock
import ru.wildanalytics.pub.analytics.util.IdGenerator
import ru.wildanalytics.pub.analytics.util.ProcessForegroundDataProvider
import ru.wildanalytics.pub.analytics.util.RandomIdGenerator
import ru.wildanalytics.pub.analytics.diagnostics.DiagnosticsReporter
import ru.wildanalytics.pub.analytics.diagnostics.EndpointFallbackReporter
import ru.wildanalytics.pub.analytics.diagnostics.QueueEvictionReporter
import ru.wildanalytics.pub.analytics.network.NetworkSnapshotProvider
import ru.wildanalytics.pub.analytics.network.NetworkSnapshotProviderImpl
import ru.wildanalytics.pub.analytics.send.RestartPolicy
import ru.wildanalytics.pub.analytics.send.fallback.EndpointFallback
import ru.wildanalytics.pub.analytics.send.fallback.EndpointRouter
import java.time.Clock
import kotlin.concurrent.Volatile

@Suppress("LongMethod")
private fun buildInstance(context: Context): WildAnalyticsServiceLocator = Builder().build {
    bindInstance(context.applicationContext)
    bindInstance<Clock>(DynamicSystemClock())
    bindInstance<WildAnalyticsLogger>(WildAnalyticsLoggerImpl())
    bindInstance<CoroutineScopeFactory>(CoroutineScopeFactoryImpl())

    bind<IdGenerator> { RandomIdGenerator() }
    bind {
        ProcessForegroundDataProvider(
            scope = it.get<CoroutineScopeFactory>().create("ForegroundData")
        )
    }
    bind<SessionProvider> {
        SessionProviderImpl(
            idGenerator = it.get(),
            processForegroundDataProvider = it.get(),
            scope = it.get<CoroutineScopeFactory>().create("SessionProvider")
        )
    }

    bind<DeviceHardwareInfoProvider> {
        DeviceHardwareInfoProviderImpl(context = it.get())
    }
    bind<AutomaticEventsTracker.Factory> {
        AutomaticEventsTracker.Factory {
            AutomaticEventsTrackerImpl(
                processForegroundDataProvider = it.get(),
                deviceHardwareInfoProvider = it.get(),
                deviceInfoProvider = it.get(),
            )
        }
    }

    bind<WildDeviceInfoProvider> {
        WildDeviceInfoProviderImpl(
            context = it.get(),
            idGenerator = it.get(),
        )
    }
    bind<WildMarketingModelProvider> {
        WildMarketingModelProviderImpl(
            log = it.get(),
        )
    }
    bind<SystemLocaleProvider> {
        SystemLocaleProviderImpl(
            context = it.get(),
            log = it.get(),
        )
    }
    bind {
        AdIdProvider(
            context = it.get(),
            log = it.get(),
            scopeFactory = it.get(),
            configs = listOf(
                IpcServiceConfig(
                    action = "com.google.android.gms.ads.identifier.service.START",
                    packageName = "com.google.android.gms",
                    descriptor = "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService",
                    providerType = "gaid",
                ),
                IpcServiceConfig(
                    action = "com.uodis.opendevice.OPENIDS_SERVICE",
                    packageName = "com.huawei.hwid",
                    descriptor = "com.uodis.opendevice.aidl.OpenDeviceIdentifierService",
                    providerType = "oaid",
                )
            )
        )
    }
    bind<WildAnalyticsDatabase> {
        WildAnalyticsDatabaseFactory.create(
            context = it.get(),
            coroutineScopeFactory = it.get(),
            logger = it.get()
        )
    }
    bind<AutomaticEventsApiKeyRegistry> {
        AutomaticEventsApiKeyRegistryImpl()
    }
    bind {
        MetadataCollector(
            deviceInfoProvider = it.get(),
            marketingModelProvider = it.get(),
            systemLocaleProvider = it.get(),
            adIdProvider = it.get(),
            automaticEventsApiKeyRegistry = it.get(),
            context = it.get(),
            clock = it.get(),
        )
    }
    bind<TransactionRunner> {
        RoomTransactionRunner(db = it.get<WildAnalyticsDatabase>())
    }
    bind {
        it.get<WildAnalyticsDatabase>().eventsDao()
    }
    bind {
        it.get<WildAnalyticsDatabase>().sentInfoDao()
    }
    bind<ConfigRepository> {
        ConfigRepositoryImpl()
    }
    bind<CustomHeadersRepository> {
        CustomHeadersRepositoryImpl()
    }
    bind<EventEnricherRegistry> {
        EventEnricherRegistryImpl(log = it.get())
    }
    bind<EventsRepository> {
        EventsRepositoryImpl(
            eventsDao = it.get(),
            db = it.get(),
        )
    }
    bind<BatchRepository> {
        BatchRepositoryImpl(
            metadataCollector = it.get(),
            transactionRunner = it.get(),
            eventsRepository = it.get(),
            sentInfoDao = it.get(),
            log = it.get(),
        )
    }

    bind<DiagnosticsReporter> {
        DiagnosticsReporter(
            log = it.get(),
            sdkVersion = "1.0.62",
        )
    }
    bind {
        SendStrategyProvider(
            eventsRepository = it.get(),
            log = it.get(),
            networkAvailabilitySource = it.get(),
            sendOperation = it.get(),
            sendOperationScheduler = it.get(),
            processForegroundDataProvider = it.get(),
        )
    }
    bind {
        WildAnalyticsSenderService(
            log = it.get(),
            configRepository = it.get(),
            coroutineScopeFactory = it.get(),
            sendStrategyProvider = it.get(),
            diagnostics = it.get(),
            restartPolicy = ru.wildanalytics.pub.analytics.send.RestartPolicy(),
        )
    }
    bind { NetworkAvailabilitySource(context = it.get()) }
    bind { SendOperationScheduler(context = it.get(), log = it.get()) }
    bind {
        SendAllAnalyticEventsOperation(
            eventsRepository = it.get(),
            batchRepository = it.get(),
            configRepository = it.get(),
            log = it.get(),
            customHeadersRepository = it.get(),
            queueEvictionReporter = it.get(),
            diagnostics = it.get(),
            endpointRouter = it.get(),
        )
    }
    bind { ru.wildanalytics.pub.analytics.send.fallback.EndpointFallback() }
    bind<ru.wildanalytics.pub.analytics.network.NetworkSnapshotProvider> {
        ru.wildanalytics.pub.analytics.network.NetworkSnapshotProviderImpl(context = it.get())
    }
    bind { ru.wildanalytics.pub.analytics.diagnostics.EndpointFallbackReporter(reporter = it.get()) }
    bind {
        ru.wildanalytics.pub.analytics.send.fallback.EndpointRouter(
            endpointFallback = it.get(),
            networkSnapshotProvider = it.get(),
            reporter = it.get(),
            log = it.get(),
        )
    }
    bind {
        ru.wildanalytics.pub.analytics.diagnostics.QueueEvictionReporter(
            reporter = it.get(),
            clock = it.get(),
            idGenerator = it.get(),
        )
    }
}

public class WildAnalyticsServiceLocator(private val providers: Map<Class<*>, (WildAnalyticsServiceLocator) -> Any>) {

    private val map = mutableMapOf<Class<*>, Any>()

    @Suppress("UNCHECKED_CAST")
    public fun <T : Any> get(clazz: Class<T>): T = synchronized(map) {
        var instance = map[clazz]
        if (instance == null) {
            instance =
                (providers[clazz] ?: error("Not found provider for ${clazz.name}")).invoke(this)
            map[clazz] = instance
        }

        instance as T
    }

    public inline fun <reified T : Any> get(): T {
        return get(T::class.java)
    }

    internal class Builder {

        private val providers = mutableMapOf<Class<*>, (WildAnalyticsServiceLocator) -> Any>()

        fun <T> bind(clazz: Class<T>, provider: (WildAnalyticsServiceLocator) -> T) {
            @Suppress("UNCHECKED_CAST")
            providers[clazz] = provider as (WildAnalyticsServiceLocator) -> Any
        }

        fun <T> bindInstance(clazz: Class<T>, instance: T) {
            bind(clazz) { instance }
        }

        inline fun <reified T> bind(noinline provider: (WildAnalyticsServiceLocator) -> T) {
            bind(T::class.java, provider)
        }

        inline fun <reified T> bindInstance(instance: T) {
            bindInstance(T::class.java, instance)
        }

        fun build(body: Builder.() -> Unit): WildAnalyticsServiceLocator {
            body()
            return WildAnalyticsServiceLocator(providers)
        }
    }

    public companion object {

        @Volatile
        private var Instance: WildAnalyticsServiceLocator? = null

        public fun getInstance(context: Context): WildAnalyticsServiceLocator = Instance
            ?: synchronized(this) {
                Instance
                    ?: buildInstance(context)
                        .also { Instance = it }
            }
    }
}
