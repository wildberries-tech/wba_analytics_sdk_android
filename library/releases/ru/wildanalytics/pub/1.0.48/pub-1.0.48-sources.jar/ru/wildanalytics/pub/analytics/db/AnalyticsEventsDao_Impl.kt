package ru.wildanalytics.pub.analytics.db

import android.database.Cursor
import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.RoomSQLiteQuery
import androidx.room.RoomSQLiteQuery.Companion.acquire
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.getTotalChangedRows
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import java.time.OffsetDateTime
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.ULong
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder
import kotlinx.serialization.json.JsonObject
import ru.wildanalytics.pub.analytics.domain.ApiData

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
internal class AnalyticsEventsDao_Impl(
  __db: RoomDatabase,
) : AnalyticsEventsDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfEventEntity: EntityInsertAdapter<EventEntity>

  private val __uLongConverter: ULongConverter = ULongConverter()

  private val __offsetDateTimeConverter: OffsetDateTimeConverter = OffsetDateTimeConverter()

  private val __keyValueConverter: KeyValueConverter = KeyValueConverter()
  init {
    this.__db = __db
    this.__insertAdapterOfEventEntity = object : EntityInsertAdapter<EventEntity>() {
      protected override fun createQuery(): String = "INSERT OR ABORT INTO `EventEntity` (`id`,`apiUrl`,`apiKey`,`name`,`sessionValue`,`time`,`extras`,`importance`) VALUES (nullif(?, 0),?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: EventEntity) {
        statement.bindLong(1, entity.id.toLong())
        statement.bindText(2, entity.apiUrl)
        statement.bindText(3, entity.apiKey)
        statement.bindText(4, entity.name)
        val _tmp: Long = __uLongConverter.fromULong(entity.sessionValue)
        statement.bindLong(5, _tmp)
        val _tmp_1: String = __offsetDateTimeConverter.fromDate(entity.time)
        statement.bindText(6, _tmp_1)
        val _tmp_2: String = __keyValueConverter.toString(entity.extras)
        statement.bindText(7, _tmp_2)
        statement.bindLong(8, entity.importance.toLong())
      }
    }
  }

  public override suspend fun add(item: EventEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfEventEntity.insert(_connection, item)
  }

  public override suspend fun add(items: List<EventEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfEventEntity.insert(_connection, items)
  }

  public override suspend fun getAll(limit: Int): List<EventEntity> {
    val _sql: String = "SELECT * FROM EventEntity LIMIT ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfApiUrl: Int = getColumnIndexOrThrow(_stmt, "apiUrl")
        val _columnIndexOfApiKey: Int = getColumnIndexOrThrow(_stmt, "apiKey")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfSessionValue: Int = getColumnIndexOrThrow(_stmt, "sessionValue")
        val _columnIndexOfTime: Int = getColumnIndexOrThrow(_stmt, "time")
        val _columnIndexOfExtras: Int = getColumnIndexOrThrow(_stmt, "extras")
        val _columnIndexOfImportance: Int = getColumnIndexOrThrow(_stmt, "importance")
        val _result: MutableList<EventEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: EventEntity
          val _tmpId: Int
          _tmpId = _stmt.getLong(_columnIndexOfId).toInt()
          val _tmpApiUrl: String
          _tmpApiUrl = _stmt.getText(_columnIndexOfApiUrl)
          val _tmpApiKey: String
          _tmpApiKey = _stmt.getText(_columnIndexOfApiKey)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpSessionValue: ULong
          val _tmp: Long
          _tmp = _stmt.getLong(_columnIndexOfSessionValue)
          _tmpSessionValue = __uLongConverter.toULong(_tmp)
          val _tmpTime: OffsetDateTime
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfTime)
          _tmpTime = __offsetDateTimeConverter.toDate(_tmp_1)
          val _tmpExtras: JsonObject
          val _tmp_2: String
          _tmp_2 = _stmt.getText(_columnIndexOfExtras)
          _tmpExtras = __keyValueConverter.fromString(_tmp_2)
          val _tmpImportance: Int
          _tmpImportance = _stmt.getLong(_columnIndexOfImportance).toInt()
          _item = EventEntity(_tmpId,_tmpApiUrl,_tmpApiKey,_tmpName,_tmpSessionValue,_tmpTime,_tmpExtras,_tmpImportance)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun queryFirst(
    apiKey: String,
    apiUrl: String,
    limit: Int,
  ): Cursor {
    val _sql: String = "SELECT * FROM EventEntity WHERE apiKey = ? AND apiUrl = ? ORDER BY importance DESC, id ASC LIMIT ?"
    val _statement: RoomSQLiteQuery = acquire(_sql, 3)
    var _argIndex: Int = 1
    _statement.bindText(_argIndex, apiKey)
    _argIndex = 2
    _statement.bindText(_argIndex, apiUrl)
    _argIndex = 3
    _statement.bindLong(_argIndex, limit.toLong())
    val _tmpResult: Cursor = __db.query(_statement)
    return _tmpResult
  }

  public override suspend fun getCount(): Int {
    val _sql: String = "SELECT COUNT(*) FROM EventEntity"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getFirstApiData(): ApiData? {
    val _sql: String = "SELECT apiKey, apiUrl FROM EventEntity ORDER BY importance DESC, id ASC LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfApiKey: Int = 0
        val _columnIndexOfApiUrl: Int = 1
        val _result: ApiData?
        if (_stmt.step()) {
          val _tmpApiKey: String
          _tmpApiKey = _stmt.getText(_columnIndexOfApiKey)
          val _tmpApiUrl: String
          _tmpApiUrl = _stmt.getText(_columnIndexOfApiUrl)
          _result = ApiData(_tmpApiUrl,_tmpApiKey)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun delete(ids: List<Int>) {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("DELETE FROM EventEntity WHERE id IN (")
    val _inputSize: Int = ids.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Int in ids) {
          _stmt.bindLong(_argIndex, _item.toLong())
          _argIndex++
        }
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteEvents(count: Int): Int {
    val _sql: String = "DELETE FROM EventEntity WHERE id IN (SELECT id FROM EventEntity LIMIT ?)"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, count.toLong())
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
