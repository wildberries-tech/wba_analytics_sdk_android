/**
 * Automatically generated file. DO NOT MODIFY
 */
package ru.wildanalytics.pub.WildAnalytics;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "ru.wildanalytics.pub.WildAnalytics";
  public static final String BUILD_TYPE = "release";
}
