package ru.wildanalytics.pub.splitter.`impl`.`data`

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performInTransactionSuspending
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
internal class SplitterPropertyDao_Impl(
  __db: RoomDatabase,
) : SplitterPropertyDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfSplitterPropertyEntity: EntityInsertAdapter<SplitterPropertyEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfSplitterPropertyEntity = object : EntityInsertAdapter<SplitterPropertyEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `splitter_properties` (`apiKey`,`abTestGroupType`,`key`,`value`) VALUES (?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: SplitterPropertyEntity) {
        statement.bindText(1, entity.apiKey)
        statement.bindText(2, entity.abTestGroupType)
        statement.bindText(3, entity.key)
        statement.bindText(4, entity.value)
      }
    }
  }

  public override suspend fun insertProperties(properties: List<SplitterPropertyEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfSplitterPropertyEntity.insert(_connection, properties)
  }

  public override suspend fun replaceProperties(apiKey: String, properties: List<SplitterPropertyEntity>): Unit = performInTransactionSuspending(__db) {
    super@SplitterPropertyDao_Impl.replaceProperties(apiKey, properties)
  }

  public override suspend fun getProperties(apiKey: String): List<SplitterPropertyEntity> {
    val _sql: String = "SELECT * FROM splitter_properties WHERE apiKey = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, apiKey)
        val _columnIndexOfApiKey: Int = getColumnIndexOrThrow(_stmt, "apiKey")
        val _columnIndexOfAbTestGroupType: Int = getColumnIndexOrThrow(_stmt, "abTestGroupType")
        val _columnIndexOfKey: Int = getColumnIndexOrThrow(_stmt, "key")
        val _columnIndexOfValue: Int = getColumnIndexOrThrow(_stmt, "value")
        val _result: MutableList<SplitterPropertyEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: SplitterPropertyEntity
          val _tmpApiKey: String
          _tmpApiKey = _stmt.getText(_columnIndexOfApiKey)
          val _tmpAbTestGroupType: String
          _tmpAbTestGroupType = _stmt.getText(_columnIndexOfAbTestGroupType)
          val _tmpKey: String
          _tmpKey = _stmt.getText(_columnIndexOfKey)
          val _tmpValue: String
          _tmpValue = _stmt.getText(_columnIndexOfValue)
          _item = SplitterPropertyEntity(_tmpApiKey,_tmpAbTestGroupType,_tmpKey,_tmpValue)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteProperties(apiKey: String) {
    val _sql: String = "DELETE FROM splitter_properties WHERE apiKey = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, apiKey)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
