package ru.wildanalytics.pub.analytics.db

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.TableInfo
import androidx.room.util.TableInfo.Companion.read
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
internal class WildAnalyticsDatabase_Impl : WildAnalyticsDatabase() {
  private val _analyticsEventsDao: Lazy<AnalyticsEventsDao> = lazy {
    AnalyticsEventsDao_Impl(this)
  }

  private val _sentInfoDao: Lazy<SentInfoDao> = lazy {
    SentInfoDao_Impl(this)
  }

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(7, "47d5784fcc7a5796372466a5f55baded", "717cf4d5281ed0857114d804911f208e") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `EventEntity` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `apiUrl` TEXT NOT NULL DEFAULT 'https://wba.wb.ru/m/batch', `apiKey` TEXT NOT NULL, `name` TEXT NOT NULL, `sessionValue` INTEGER NOT NULL DEFAULT 0, `time` TEXT NOT NULL, `extras` TEXT NOT NULL, `importance` INTEGER NOT NULL DEFAULT 0)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_EventEntity_importance_id` ON `EventEntity` (`importance` DESC, `id` ASC)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `SentInfoEntity` (`id` INTEGER NOT NULL, `batchesSent` INTEGER NOT NULL, `eventsSent` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '47d5784fcc7a5796372466a5f55baded')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `EventEntity`")
        connection.execSQL("DROP TABLE IF EXISTS `SentInfoEntity`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
      }

      public override fun onValidateSchema(connection: SQLiteConnection): RoomOpenDelegate.ValidationResult {
        val _columnsEventEntity: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsEventEntity.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEventEntity.put("apiUrl", TableInfo.Column("apiUrl", "TEXT", true, 0, "'https://wba.wb.ru/m/batch'", TableInfo.CREATED_FROM_ENTITY))
        _columnsEventEntity.put("apiKey", TableInfo.Column("apiKey", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEventEntity.put("name", TableInfo.Column("name", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEventEntity.put("sessionValue", TableInfo.Column("sessionValue", "INTEGER", true, 0, "0", TableInfo.CREATED_FROM_ENTITY))
        _columnsEventEntity.put("time", TableInfo.Column("time", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEventEntity.put("extras", TableInfo.Column("extras", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEventEntity.put("importance", TableInfo.Column("importance", "INTEGER", true, 0, "0", TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysEventEntity: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesEventEntity: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesEventEntity.add(TableInfo.Index("index_EventEntity_importance_id", false, listOf("importance", "id"), listOf("DESC", "ASC")))
        val _infoEventEntity: TableInfo = TableInfo("EventEntity", _columnsEventEntity, _foreignKeysEventEntity, _indicesEventEntity)
        val _existingEventEntity: TableInfo = read(connection, "EventEntity")
        if (!_infoEventEntity.equals(_existingEventEntity)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |EventEntity(ru.wildanalytics.pub.analytics.db.EventEntity).
              | Expected:
              |""".trimMargin() + _infoEventEntity + """
              |
              | Found:
              |""".trimMargin() + _existingEventEntity)
        }
        val _columnsSentInfoEntity: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsSentInfoEntity.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSentInfoEntity.put("batchesSent", TableInfo.Column("batchesSent", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSentInfoEntity.put("eventsSent", TableInfo.Column("eventsSent", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysSentInfoEntity: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesSentInfoEntity: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoSentInfoEntity: TableInfo = TableInfo("SentInfoEntity", _columnsSentInfoEntity, _foreignKeysSentInfoEntity, _indicesSentInfoEntity)
        val _existingSentInfoEntity: TableInfo = read(connection, "SentInfoEntity")
        if (!_infoSentInfoEntity.equals(_existingSentInfoEntity)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |SentInfoEntity(ru.wildanalytics.pub.analytics.db.SentInfoEntity).
              | Expected:
              |""".trimMargin() + _infoSentInfoEntity + """
              |
              | Found:
              |""".trimMargin() + _existingSentInfoEntity)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "EventEntity", "SentInfoEntity")
  }

  public override fun clearAllTables() {
    super.performClear(false, "EventEntity", "SentInfoEntity")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(AnalyticsEventsDao::class, AnalyticsEventsDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(SentInfoDao::class, SentInfoDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>): List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    _autoMigrations.add(WildAnalyticsDatabase_AutoMigration_1_7_Impl())
    return _autoMigrations
  }

  public override fun eventsDao(): AnalyticsEventsDao = _analyticsEventsDao.value

  public override fun sentInfoDao(): SentInfoDao = _sentInfoDao.value
}
