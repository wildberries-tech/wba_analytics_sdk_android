package ru.wildanalytics.pub.analytics.db

import androidx.room.migration.Migration
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Suppress

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
internal class WildAnalyticsDatabase_AutoMigration_1_7_Impl : Migration {
  public constructor() : super(1, 7)

  public override fun migrate(connection: SQLiteConnection) {
    connection.execSQL("ALTER TABLE `EventEntity` ADD COLUMN `sessionValue` INTEGER NOT NULL DEFAULT 0")
  }
}
