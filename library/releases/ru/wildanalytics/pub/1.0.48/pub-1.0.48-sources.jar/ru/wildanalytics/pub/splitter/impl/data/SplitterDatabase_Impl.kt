package ru.wildanalytics.pub.splitter.`impl`.`data`

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.TableInfo
import androidx.room.util.TableInfo.Companion.read
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
internal class SplitterDatabase_Impl : SplitterDatabase() {
  private val _splitterPropertyDao: Lazy<SplitterPropertyDao> = lazy {
    SplitterPropertyDao_Impl(this)
  }

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(1, "ddbcfa5c0d71e3102be87a2da077033e", "c055a10f20111e54266df5269c004502") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `splitter_properties` (`apiKey` TEXT NOT NULL, `abTestGroupType` TEXT NOT NULL, `key` TEXT NOT NULL, `value` TEXT NOT NULL, PRIMARY KEY(`apiKey`, `abTestGroupType`, `key`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'ddbcfa5c0d71e3102be87a2da077033e')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `splitter_properties`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
      }

      public override fun onValidateSchema(connection: SQLiteConnection): RoomOpenDelegate.ValidationResult {
        val _columnsSplitterProperties: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsSplitterProperties.put("apiKey", TableInfo.Column("apiKey", "TEXT", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSplitterProperties.put("abTestGroupType", TableInfo.Column("abTestGroupType", "TEXT", true, 2, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSplitterProperties.put("key", TableInfo.Column("key", "TEXT", true, 3, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSplitterProperties.put("value", TableInfo.Column("value", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysSplitterProperties: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesSplitterProperties: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoSplitterProperties: TableInfo = TableInfo("splitter_properties", _columnsSplitterProperties, _foreignKeysSplitterProperties, _indicesSplitterProperties)
        val _existingSplitterProperties: TableInfo = read(connection, "splitter_properties")
        if (!_infoSplitterProperties.equals(_existingSplitterProperties)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |splitter_properties(ru.wildanalytics.pub.splitter.impl.data.SplitterPropertyEntity).
              | Expected:
              |""".trimMargin() + _infoSplitterProperties + """
              |
              | Found:
              |""".trimMargin() + _existingSplitterProperties)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "splitter_properties")
  }

  public override fun clearAllTables() {
    super.performClear(false, "splitter_properties")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(SplitterPropertyDao::class, SplitterPropertyDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>): List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    return _autoMigrations
  }

  public override fun splitterPropertyDao(): SplitterPropertyDao = _splitterPropertyDao.value
}
