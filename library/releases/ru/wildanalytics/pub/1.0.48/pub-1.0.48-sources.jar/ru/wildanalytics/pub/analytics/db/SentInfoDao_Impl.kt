package ru.wildanalytics.pub.analytics.db

import androidx.room.EntityDeleteOrUpdateAdapter
import androidx.room.EntityInsertAdapter
import androidx.room.EntityUpsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
internal class SentInfoDao_Impl(
  __db: RoomDatabase,
) : SentInfoDao {
  private val __db: RoomDatabase

  private val __upsertAdapterOfSentInfoEntity: EntityUpsertAdapter<SentInfoEntity>
  init {
    this.__db = __db
    this.__upsertAdapterOfSentInfoEntity = EntityUpsertAdapter<SentInfoEntity>(object : EntityInsertAdapter<SentInfoEntity>() {
      protected override fun createQuery(): String = "INSERT INTO `SentInfoEntity` (`id`,`batchesSent`,`eventsSent`) VALUES (?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: SentInfoEntity) {
        statement.bindLong(1, entity.id.toLong())
        statement.bindLong(2, entity.batchesSent)
        statement.bindLong(3, entity.eventsSent)
      }
    }, object : EntityDeleteOrUpdateAdapter<SentInfoEntity>() {
      protected override fun createQuery(): String = "UPDATE `SentInfoEntity` SET `id` = ?,`batchesSent` = ?,`eventsSent` = ? WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: SentInfoEntity) {
        statement.bindLong(1, entity.id.toLong())
        statement.bindLong(2, entity.batchesSent)
        statement.bindLong(3, entity.eventsSent)
        statement.bindLong(4, entity.id.toLong())
      }
    })
  }

  public override suspend fun upsert(info: SentInfoEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __upsertAdapterOfSentInfoEntity.upsert(_connection, info)
  }

  public override suspend fun getSentInfo(): SentInfoEntity? {
    val _sql: String = "SELECT * FROM SentInfoEntity"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfBatchesSent: Int = getColumnIndexOrThrow(_stmt, "batchesSent")
        val _columnIndexOfEventsSent: Int = getColumnIndexOrThrow(_stmt, "eventsSent")
        val _result: SentInfoEntity?
        if (_stmt.step()) {
          val _tmpId: Int
          _tmpId = _stmt.getLong(_columnIndexOfId).toInt()
          val _tmpBatchesSent: Long
          _tmpBatchesSent = _stmt.getLong(_columnIndexOfBatchesSent)
          val _tmpEventsSent: Long
          _tmpEventsSent = _stmt.getLong(_columnIndexOfEventsSent)
          _result = SentInfoEntity(_tmpId,_tmpBatchesSent,_tmpEventsSent)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
