package ru.wildberries.analytics.db;

import androidx.annotation.NonNull;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;
import java.lang.Override;
import java.lang.SuppressWarnings;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
final class WBAnalytics2Database_AutoMigration_3_4_Impl extends Migration {
  public WBAnalytics2Database_AutoMigration_3_4_Impl() {
    super(3, 4);
  }

  @Override
  public void migrate(@NonNull final SupportSQLiteDatabase db) {
    db.execSQL("ALTER TABLE `EventEntity` ADD COLUMN `apiUrl` TEXT NOT NULL DEFAULT 'https://a.wb.ru/m/batch'");
  }
}
