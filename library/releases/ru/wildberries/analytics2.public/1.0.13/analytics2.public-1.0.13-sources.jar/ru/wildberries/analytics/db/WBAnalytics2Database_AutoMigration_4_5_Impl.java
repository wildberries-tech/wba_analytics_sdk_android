package ru.wildberries.analytics.db;

import androidx.annotation.NonNull;
import androidx.room.migration.AutoMigrationSpec;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;
import java.lang.Override;
import java.lang.SuppressWarnings;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
final class WBAnalytics2Database_AutoMigration_4_5_Impl extends Migration {
  private final AutoMigrationSpec callback = new AutoMigration4to5();

  public WBAnalytics2Database_AutoMigration_4_5_Impl() {
    super(4, 5);
  }

  @Override
  public void migrate(@NonNull final SupportSQLiteDatabase db) {
    db.execSQL("CREATE TABLE IF NOT EXISTS `SentInfoEntity` (`id` INTEGER NOT NULL, `batchesSent` INTEGER NOT NULL, `eventsSent` INTEGER NOT NULL, PRIMARY KEY(`id`))");
    db.execSQL("CREATE TABLE IF NOT EXISTS `_new_EventEntity` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `apiUrl` TEXT NOT NULL DEFAULT 'https://wba.wb.ru/m/batch', `apiKey` TEXT NOT NULL, `name` TEXT NOT NULL, `time` TEXT NOT NULL, `extras` TEXT NOT NULL)");
    db.execSQL("INSERT INTO `_new_EventEntity` (`id`,`apiUrl`,`apiKey`,`name`,`time`,`extras`) SELECT `id`,`apiUrl`,`apiKey`,`name`,`time`,`extras` FROM `EventEntity`");
    db.execSQL("DROP TABLE `EventEntity`");
    db.execSQL("ALTER TABLE `_new_EventEntity` RENAME TO `EventEntity`");
    callback.onPostMigrate(db);
  }
}
