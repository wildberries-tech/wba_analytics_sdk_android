package ru.wildberries.analytics.db;

import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.CoroutinesRoom;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.EntityUpsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import java.lang.Class;
import java.lang.Exception;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.processing.Generated;
import kotlin.Unit;
import kotlin.coroutines.Continuation;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class SentInfoDao_Impl implements SentInfoDao {
  private final RoomDatabase __db;

  private final EntityUpsertionAdapter<SentInfoEntity> __upsertionAdapterOfSentInfoEntity;

  public SentInfoDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__upsertionAdapterOfSentInfoEntity = new EntityUpsertionAdapter<SentInfoEntity>(new EntityInsertionAdapter<SentInfoEntity>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT INTO `SentInfoEntity` (`id`,`batchesSent`,`eventsSent`) VALUES (?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final SentInfoEntity entity) {
        statement.bindLong(1, entity.getId());
        statement.bindLong(2, entity.getBatchesSent());
        statement.bindLong(3, entity.getEventsSent());
      }
    }, new EntityDeletionOrUpdateAdapter<SentInfoEntity>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "UPDATE `SentInfoEntity` SET `id` = ?,`batchesSent` = ?,`eventsSent` = ? WHERE `id` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final SentInfoEntity entity) {
        statement.bindLong(1, entity.getId());
        statement.bindLong(2, entity.getBatchesSent());
        statement.bindLong(3, entity.getEventsSent());
        statement.bindLong(4, entity.getId());
      }
    });
  }

  @Override
  public Object upsert(final SentInfoEntity info, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __upsertionAdapterOfSentInfoEntity.upsert(info);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object getSentInfo(final Continuation<? super SentInfoEntity> $completion) {
    final String _sql = "SELECT * FROM SentInfoEntity";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<SentInfoEntity>() {
      @Override
      @Nullable
      public SentInfoEntity call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfBatchesSent = CursorUtil.getColumnIndexOrThrow(_cursor, "batchesSent");
          final int _cursorIndexOfEventsSent = CursorUtil.getColumnIndexOrThrow(_cursor, "eventsSent");
          final SentInfoEntity _result;
          if (_cursor.moveToFirst()) {
            final int _tmpId;
            _tmpId = _cursor.getInt(_cursorIndexOfId);
            final long _tmpBatchesSent;
            _tmpBatchesSent = _cursor.getLong(_cursorIndexOfBatchesSent);
            final long _tmpEventsSent;
            _tmpEventsSent = _cursor.getLong(_cursorIndexOfEventsSent);
            _result = new SentInfoEntity(_tmpId,_tmpBatchesSent,_tmpEventsSent);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
