/**
 * Automatically generated file. DO NOT MODIFY
 */
package ru.wildberries.WBAnalytics2;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "ru.wildberries.WBAnalytics2";
  public static final String BUILD_TYPE = "release";
}
