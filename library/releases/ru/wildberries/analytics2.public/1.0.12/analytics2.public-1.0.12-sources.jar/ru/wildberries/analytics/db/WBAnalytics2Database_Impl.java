package ru.wildberries.analytics.db;

import androidx.annotation.NonNull;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomOpenHelper;
import androidx.room.migration.AutoMigrationSpec;
import androidx.room.migration.Migration;
import androidx.room.util.DBUtil;
import androidx.room.util.TableInfo;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class WBAnalytics2Database_Impl extends WBAnalytics2Database {
  private volatile AnalyticsEventsDao _analyticsEventsDao;

  private volatile SentInfoDao _sentInfoDao;

  @Override
  @NonNull
  protected SupportSQLiteOpenHelper createOpenHelper(@NonNull final DatabaseConfiguration config) {
    final SupportSQLiteOpenHelper.Callback _openCallback = new RoomOpenHelper(config, new RoomOpenHelper.Delegate(5) {
      @Override
      public void createAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `EventEntity` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `apiUrl` TEXT NOT NULL DEFAULT 'https://a.wb.ru/m/batch', `apiKey` TEXT NOT NULL, `name` TEXT NOT NULL, `time` TEXT NOT NULL, `extras` TEXT NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS `SentInfoEntity` (`id` INTEGER NOT NULL, `batchesSent` INTEGER NOT NULL, `eventsSent` INTEGER NOT NULL, PRIMARY KEY(`id`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
        db.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'cbc069380b7c1bf5a17adde0803d27a8')");
      }

      @Override
      public void dropAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("DROP TABLE IF EXISTS `EventEntity`");
        db.execSQL("DROP TABLE IF EXISTS `SentInfoEntity`");
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onDestructiveMigration(db);
          }
        }
      }

      @Override
      public void onCreate(@NonNull final SupportSQLiteDatabase db) {
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onCreate(db);
          }
        }
      }

      @Override
      public void onOpen(@NonNull final SupportSQLiteDatabase db) {
        mDatabase = db;
        internalInitInvalidationTracker(db);
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onOpen(db);
          }
        }
      }

      @Override
      public void onPreMigrate(@NonNull final SupportSQLiteDatabase db) {
        DBUtil.dropFtsSyncTriggers(db);
      }

      @Override
      public void onPostMigrate(@NonNull final SupportSQLiteDatabase db) {
      }

      @Override
      @NonNull
      public RoomOpenHelper.ValidationResult onValidateSchema(
          @NonNull final SupportSQLiteDatabase db) {
        final HashMap<String, TableInfo.Column> _columnsEventEntity = new HashMap<String, TableInfo.Column>(6);
        _columnsEventEntity.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsEventEntity.put("apiUrl", new TableInfo.Column("apiUrl", "TEXT", true, 0, "'https://a.wb.ru/m/batch'", TableInfo.CREATED_FROM_ENTITY));
        _columnsEventEntity.put("apiKey", new TableInfo.Column("apiKey", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsEventEntity.put("name", new TableInfo.Column("name", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsEventEntity.put("time", new TableInfo.Column("time", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsEventEntity.put("extras", new TableInfo.Column("extras", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysEventEntity = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesEventEntity = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoEventEntity = new TableInfo("EventEntity", _columnsEventEntity, _foreignKeysEventEntity, _indicesEventEntity);
        final TableInfo _existingEventEntity = TableInfo.read(db, "EventEntity");
        if (!_infoEventEntity.equals(_existingEventEntity)) {
          return new RoomOpenHelper.ValidationResult(false, "EventEntity(ru.wildberries.analytics.db.EventEntity).\n"
                  + " Expected:\n" + _infoEventEntity + "\n"
                  + " Found:\n" + _existingEventEntity);
        }
        final HashMap<String, TableInfo.Column> _columnsSentInfoEntity = new HashMap<String, TableInfo.Column>(3);
        _columnsSentInfoEntity.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsSentInfoEntity.put("batchesSent", new TableInfo.Column("batchesSent", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsSentInfoEntity.put("eventsSent", new TableInfo.Column("eventsSent", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysSentInfoEntity = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesSentInfoEntity = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoSentInfoEntity = new TableInfo("SentInfoEntity", _columnsSentInfoEntity, _foreignKeysSentInfoEntity, _indicesSentInfoEntity);
        final TableInfo _existingSentInfoEntity = TableInfo.read(db, "SentInfoEntity");
        if (!_infoSentInfoEntity.equals(_existingSentInfoEntity)) {
          return new RoomOpenHelper.ValidationResult(false, "SentInfoEntity(ru.wildberries.analytics.db.SentInfoEntity).\n"
                  + " Expected:\n" + _infoSentInfoEntity + "\n"
                  + " Found:\n" + _existingSentInfoEntity);
        }
        return new RoomOpenHelper.ValidationResult(true, null);
      }
    }, "cbc069380b7c1bf5a17adde0803d27a8", "8fb8931995527cd5b1a36a68e3c766da");
    final SupportSQLiteOpenHelper.Configuration _sqliteConfig = SupportSQLiteOpenHelper.Configuration.builder(config.context).name(config.name).callback(_openCallback).build();
    final SupportSQLiteOpenHelper _helper = config.sqliteOpenHelperFactory.create(_sqliteConfig);
    return _helper;
  }

  @Override
  @NonNull
  protected InvalidationTracker createInvalidationTracker() {
    final HashMap<String, String> _shadowTablesMap = new HashMap<String, String>(0);
    final HashMap<String, Set<String>> _viewTables = new HashMap<String, Set<String>>(0);
    return new InvalidationTracker(this, _shadowTablesMap, _viewTables, "EventEntity","SentInfoEntity");
  }

  @Override
  public void clearAllTables() {
    super.assertNotMainThread();
    final SupportSQLiteDatabase _db = super.getOpenHelper().getWritableDatabase();
    try {
      super.beginTransaction();
      _db.execSQL("DELETE FROM `EventEntity`");
      _db.execSQL("DELETE FROM `SentInfoEntity`");
      super.setTransactionSuccessful();
    } finally {
      super.endTransaction();
      _db.query("PRAGMA wal_checkpoint(FULL)").close();
      if (!_db.inTransaction()) {
        _db.execSQL("VACUUM");
      }
    }
  }

  @Override
  @NonNull
  protected Map<Class<?>, List<Class<?>>> getRequiredTypeConverters() {
    final HashMap<Class<?>, List<Class<?>>> _typeConvertersMap = new HashMap<Class<?>, List<Class<?>>>();
    _typeConvertersMap.put(AnalyticsEventsDao.class, AnalyticsEventsDao_Impl.getRequiredConverters());
    _typeConvertersMap.put(SentInfoDao.class, SentInfoDao_Impl.getRequiredConverters());
    return _typeConvertersMap;
  }

  @Override
  @NonNull
  public Set<Class<? extends AutoMigrationSpec>> getRequiredAutoMigrationSpecs() {
    final HashSet<Class<? extends AutoMigrationSpec>> _autoMigrationSpecsSet = new HashSet<Class<? extends AutoMigrationSpec>>();
    return _autoMigrationSpecsSet;
  }

  @Override
  @NonNull
  public List<Migration> getAutoMigrations(
      @NonNull final Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> autoMigrationSpecs) {
    final List<Migration> _autoMigrations = new ArrayList<Migration>();
    _autoMigrations.add(new WBAnalytics2Database_AutoMigration_3_4_Impl());
    _autoMigrations.add(new WBAnalytics2Database_AutoMigration_4_5_Impl());
    return _autoMigrations;
  }

  @Override
  public AnalyticsEventsDao eventsDao() {
    if (_analyticsEventsDao != null) {
      return _analyticsEventsDao;
    } else {
      synchronized(this) {
        if(_analyticsEventsDao == null) {
          _analyticsEventsDao = new AnalyticsEventsDao_Impl(this);
        }
        return _analyticsEventsDao;
      }
    }
  }

  @Override
  public SentInfoDao sentInfoDao() {
    if (_sentInfoDao != null) {
      return _sentInfoDao;
    } else {
      synchronized(this) {
        if(_sentInfoDao == null) {
          _sentInfoDao = new SentInfoDao_Impl(this);
        }
        return _sentInfoDao;
      }
    }
  }
}
