package ru.wildberries.pub.analytics.db

import androidx.room.migration.Migration
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Suppress

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
internal class WBAnalytics2Database_AutoMigration_5_6_Impl : Migration {
  public constructor() : super(5, 6)

  public override fun migrate(connection: SQLiteConnection) {
    connection.execSQL("CREATE TABLE IF NOT EXISTS `_new_EventEntity` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `apiUrl` TEXT NOT NULL DEFAULT 'https://a.wb.ru/m/batch', `apiKey` TEXT NOT NULL, `name` TEXT NOT NULL, `time` TEXT NOT NULL, `extras` TEXT NOT NULL, `importance` INTEGER NOT NULL DEFAULT 0)")
    connection.execSQL("INSERT INTO `_new_EventEntity` (`id`,`apiUrl`,`apiKey`,`name`,`time`,`extras`) SELECT `id`,`apiUrl`,`apiKey`,`name`,`time`,`extras` FROM `EventEntity`")
    connection.execSQL("DROP TABLE `EventEntity`")
    connection.execSQL("ALTER TABLE `_new_EventEntity` RENAME TO `EventEntity`")
    connection.execSQL("CREATE INDEX IF NOT EXISTS `index_EventEntity_importance_id` ON `EventEntity` (`importance` DESC, `id` ASC)")
  }
}
