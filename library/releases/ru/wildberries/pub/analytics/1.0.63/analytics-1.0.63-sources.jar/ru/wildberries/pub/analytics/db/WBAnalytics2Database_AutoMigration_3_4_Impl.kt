package ru.wildberries.pub.analytics.db

import androidx.room.migration.Migration
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Suppress

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
internal class WBAnalytics2Database_AutoMigration_3_4_Impl : Migration {
  public constructor() : super(3, 4)

  public override fun migrate(connection: SQLiteConnection) {
    connection.execSQL("ALTER TABLE `EventEntity` ADD COLUMN `apiUrl` TEXT NOT NULL DEFAULT 'https://a.wb.ru/m/batch'")
  }
}
