package ru.wildberries.pub.analytics.db

import androidx.room.migration.Migration
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Suppress

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
internal class WBAnalytics2Database_AutoMigration_6_7_Impl : Migration {
  public constructor() : super(6, 7)

  public override fun migrate(connection: SQLiteConnection) {
    connection.execSQL("ALTER TABLE `EventEntity` ADD COLUMN `sessionValue` INTEGER NOT NULL DEFAULT 0")
  }
}
