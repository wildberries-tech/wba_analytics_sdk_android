package ru.wildberries.pub.analytics.db

import androidx.room.migration.Migration
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Suppress

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
internal class WBAnalytics2Database_AutoMigration_4_5_Impl : Migration {
  public constructor() : super(4, 5)

  public override fun migrate(connection: SQLiteConnection) {
    connection.execSQL("CREATE TABLE IF NOT EXISTS `SentInfoEntity` (`id` INTEGER NOT NULL, `batchesSent` INTEGER NOT NULL, `eventsSent` INTEGER NOT NULL, PRIMARY KEY(`id`))")
  }
}
